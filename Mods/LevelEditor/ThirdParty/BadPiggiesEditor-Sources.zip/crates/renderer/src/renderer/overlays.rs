//! HUD overlays, selection visuals, terrain wireframe, grid, and lazy texture loading.

use std::collections::BTreeSet;

use crate::data::assets;
use crate::domain::types::{ObjectIndex, Vec2};

use super::{ATLAS_FILES, CursorMode, GLOW_ATLAS, GOAL_FLAG_TEXTURE, LevelRenderer, particles};

const GRID_LINE_WIDTH: f32 = 1.0;

fn snap_grid_line_to_pixel_center(coordinate: f32) -> f32 {
    coordinate.floor() + 0.5
}

fn circle_center_from_three_points(p0: Vec2, p1: Vec2, p2: Vec2) -> Option<Vec2> {
    let x1 = p0.x;
    let y1 = p0.y;
    let x2 = p1.x;
    let y2 = p1.y;
    let x3 = p2.x;
    let y3 = p2.y;

    let d = 2.0 * (x1 * (y2 - y3) + x2 * (y3 - y1) + x3 * (y1 - y2));
    if d.abs() < 1e-6 {
        return None;
    }

    let x1_sq_y1_sq = x1 * x1 + y1 * y1;
    let x2_sq_y2_sq = x2 * x2 + y2 * y2;
    let x3_sq_y3_sq = x3 * x3 + y3 * y3;

    let ux = (x1_sq_y1_sq * (y2 - y3) + x2_sq_y2_sq * (y3 - y1) + x3_sq_y3_sq * (y1 - y2)) / d;
    let uy = (x1_sq_y1_sq * (x3 - x2) + x2_sq_y2_sq * (x1 - x3) + x3_sq_y3_sq * (x2 - x1)) / d;
    Some(Vec2 { x: ux, y: uy })
}

fn angle_delta_ccw(from: f32, to: f32) -> f32 {
    let tau = std::f32::consts::TAU;
    (to - from).rem_euclid(tau)
}

fn sample_circular_arc_preview(
    p0: Vec2,
    through: Vec2,
    p2: Vec2,
    nodes: usize,
) -> Option<Vec<Vec2>> {
    let center = circle_center_from_three_points(p0, through, p2)?;
    let radius = ((p0.x - center.x).powi(2) + (p0.y - center.y).powi(2)).sqrt();
    if radius < 1e-6 {
        return None;
    }

    let a0 = (p0.y - center.y).atan2(p0.x - center.x);
    let a1 = (through.y - center.y).atan2(through.x - center.x);
    let a2 = (p2.y - center.y).atan2(p2.x - center.x);

    let sweep = {
        let ccw_01 = angle_delta_ccw(a0, a1);
        let ccw_02 = angle_delta_ccw(a0, a2);
        if ccw_01 <= ccw_02 {
            ccw_02
        } else {
            -angle_delta_ccw(a2, a0)
        }
    };

    let n = nodes.clamp(3, 256);
    let mut points = Vec::with_capacity(n);
    let denom = (n - 1) as f32;
    for i in 0..n {
        let t = i as f32 / denom;
        let angle = a0 + sweep * t;
        points.push(Vec2 {
            x: center.x + radius * angle.cos(),
            y: center.y + radius * angle.sin(),
        });
    }
    Some(points)
}

fn bounds_center(bounds: [f32; 4]) -> Vec2 {
    let [tl_x, tl_y, w, h] = bounds;
    Vec2 {
        x: tl_x + w * 0.5,
        y: tl_y - h * 0.5,
    }
}

fn catmull_rom(p0: f32, p1: f32, p2: f32, p3: f32, t: f32) -> f32 {
    let t2 = t * t;
    let t3 = t2 * t;
    0.5 * ((2.0 * p1)
        + (-p0 + p2) * t
        + (2.0 * p0 - 5.0 * p1 + 4.0 * p2 - p3) * t2
        + (-p0 + 3.0 * p1 - 3.0 * p2 + p3) * t3)
}

fn sample_bple_preview_route(points: &[Vec2]) -> Vec<Vec2> {
    if points.len() < 2 {
        return points.to_vec();
    }
    if points.len() == 2 {
        return points.to_vec();
    }

    let mut cp = Vec::with_capacity(points.len() + 2);
    cp.push(points[0]);
    cp.extend_from_slice(points);
    cp.push(*points.last().unwrap_or(&points[0]));

    let mut out = Vec::new();
    for i in 1..(cp.len() - 2) {
        let p0 = cp[i - 1];
        let p1 = cp[i];
        let p2 = cp[i + 1];
        let p3 = cp[i + 2];
        let samples = 20;
        for s in 0..samples {
            let t = s as f32 / samples as f32;
            out.push(Vec2 {
                x: catmull_rom(p0.x, p1.x, p2.x, p3.x, t),
                y: catmull_rom(p0.y, p1.y, p2.y, p3.y, t),
            });
        }
    }
    if let Some(last) = points.last().copied() {
        out.push(last);
    }
    out
}

/// Catmull-Rom closed loop: the path wraps back to the first point.
/// The serialised control points in sandbox levels already start and end near
/// the same position, but we still close the wrap in the ghost padded array so
/// the interpolation is smooth through the seam.
fn sample_bple_sandbox_route(points: &[Vec2]) -> Vec<Vec2> {
    let n = points.len();
    if n < 2 {
        return points.to_vec();
    }
    // Pad with wrap-around neighbours so tangents at the endpoints are smooth.
    // cp[0] = points[n-1], cp[1..=n] = original, cp[n+1] = points[0]
    let mut cp = Vec::with_capacity(n + 2);
    cp.push(points[n - 1]);
    cp.extend_from_slice(points);
    cp.push(points[0]);

    let mut out = Vec::new();
    // Only iterate up to n-1 so the last point does NOT connect back to the first.
    for i in 1..n {
        let p0 = cp[i - 1];
        let p1 = cp[i];
        let p2 = cp[(i + 1) % cp.len()];
        let p3 = cp[(i + 2) % cp.len()];
        let samples = 20;
        for s in 0..samples {
            let t = s as f32 / samples as f32;
            out.push(Vec2 {
                x: catmull_rom(p0.x, p1.x, p2.x, p3.x, t),
                y: catmull_rom(p0.y, p1.y, p2.y, p3.y, t),
            });
        }
    }
    // Append the final control point exactly so the line ends there.
    if let Some(&last) = points.last() {
        out.push(last);
    }
    out
}

fn draw_dashed_polyline(
    painter: &crate::gpu2d::Painter,
    pts: &[crate::gpu2d::Pos2],
    stroke: crate::gpu2d::Stroke,
    dash_len: f32,
    gap_len: f32,
) {
    if pts.len() < 2 {
        return;
    }
    for pair in pts.windows(2) {
        let a = pair[0];
        let b = pair[1];
        let dx = b.x - a.x;
        let dy = b.y - a.y;
        let len = (dx * dx + dy * dy).sqrt();
        if len <= 1e-3 {
            continue;
        }
        let ux = dx / len;
        let uy = dy / len;
        let mut dist = 0.0;
        while dist < len {
            let d0 = dist;
            let d1 = (dist + dash_len).min(len);
            let p0 = crate::gpu2d::pos2(a.x + ux * d0, a.y + uy * d0);
            let p1 = crate::gpu2d::pos2(a.x + ux * d1, a.y + uy * d1);
            painter.line_segment([p0, p1], stroke);
            dist += dash_len + gap_len;
        }
    }
}

fn draw_arrow_head(
    painter: &crate::gpu2d::Painter,
    tip: crate::gpu2d::Pos2,
    from: crate::gpu2d::Pos2,
    stroke: crate::gpu2d::Stroke,
) {
    let dx = tip.x - from.x;
    let dy = tip.y - from.y;
    let len = (dx * dx + dy * dy).sqrt();
    if len <= 1e-3 {
        return;
    }

    let ux = dx / len;
    let uy = dy / len;
    let arrow_len = 12.0;
    let arrow_spread = 0.45;
    let back_x = tip.x - ux * arrow_len;
    let back_y = tip.y - uy * arrow_len;
    let left = crate::gpu2d::pos2(
        back_x - uy * arrow_len * arrow_spread,
        back_y + ux * arrow_len * arrow_spread,
    );
    let right = crate::gpu2d::pos2(
        back_x + uy * arrow_len * arrow_spread,
        back_y - ux * arrow_len * arrow_spread,
    );
    painter.line_segment([left, tip], stroke);
    painter.line_segment([right, tip], stroke);
}

fn draw_route_node(
    painter: &crate::gpu2d::Painter,
    pos: crate::gpu2d::Pos2,
    radius: f32,
    fill: crate::gpu2d::Color32,
    stroke: crate::gpu2d::Stroke,
    label: &str,
) {
    painter.circle_filled(pos, radius, fill);
    painter.circle_stroke(pos, radius, stroke);
    painter.text(
        pos + crate::gpu2d::vec2(radius + 4.0, -radius - 2.0),
        crate::gpu2d::Align2::LEFT_TOP,
        label,
        crate::gpu2d::FontId::proportional(11.0),
        fill,
    );
}

impl LevelRenderer {
    /// Draw terrain triangulation wireframe overlay.
    pub(super) fn draw_terrain_wireframe(
        &self,
        painter: &crate::gpu2d::Painter,
        rect: crate::gpu2d::Rect,
    ) {
        let Some(resources) = self.wireframe_resources.as_ref() else {
            return;
        };
        let screen_size = [rect.width(), rect.height()];
        for (terrain_index, terrain) in self.terrain_data.iter().enumerate() {
            let Some(Some(mesh)) = self.wireframe_gpu_meshes.get(terrain_index) else {
                continue;
            };
            let (drag_x, drag_y) = self.terrain_drag_offset(terrain.object_index);
            let camera_center = [self.camera.center.x - drag_x, self.camera.center.y - drag_y];
            if !mesh.is_visible(screen_size, camera_center, self.camera.zoom) {
                continue;
            }
            painter.add(crate::renderer::wireframe_shader::make_wireframe_callback(
                rect,
                resources.clone(),
                mesh.clone(),
                crate::renderer::wireframe_shader::WireframeUniforms {
                    screen_size,
                    camera_center,
                    zoom: self.camera.zoom,
                    _pad0: 0.0,
                    _pad1: [0.0; 2],
                    // Premultiplied equivalent of rgba(0, 255, 128, 160).
                    color: [0.0, 160.0 / 255.0, 80.0 / 255.0, 160.0 / 255.0],
                },
            ));
        }
    }

    /// Draw selection outlines and node handles for terrain curves.
    pub(super) fn draw_terrain_selection(
        &mut self,
        painter: &crate::gpu2d::Painter,
        canvas_center: crate::gpu2d::Vec2,
        selected: &BTreeSet<ObjectIndex>,
    ) {
        self.hovered_terrain_node = None;
        for td in self.terrain_data.iter() {
            if selected.contains(&td.object_index) && td.curve_world_verts.len() >= 2 {
                let (tdx, tdy) = self.terrain_drag_offset(td.object_index);
                let screen_pts: Vec<crate::gpu2d::Pos2> = td
                    .curve_world_verts
                    .iter()
                    .map(|&(wx, wy)| {
                        self.camera.world_to_screen(
                            Vec2 {
                                x: wx + tdx,
                                y: wy + tdy,
                            },
                            canvas_center,
                        )
                    })
                    .collect();
                let stroke = crate::gpu2d::Stroke::new(2.0, crate::gpu2d::Color32::YELLOW);
                for pair in screen_pts.windows(2) {
                    painter.line_segment([pair[0], pair[1]], stroke);
                }

                // Node handles: draw small squares at each curve node position
                const NODE_RADIUS: f32 = 4.0;
                const HOVER_RADIUS: f32 = 8.0;

                // Find hovered node (closest within threshold)
                if let Some(mouse_w) = self.mouse_world {
                    let mouse_wx = mouse_w.x - tdx;
                    let mouse_wy = mouse_w.y - tdy;
                    let threshold = HOVER_RADIUS / self.camera.zoom;
                    let mut best_dist = threshold;
                    let mut best_idx = None;
                    for (i, &(nx, ny)) in td.curve_world_verts.iter().enumerate() {
                        let dx = nx - mouse_wx;
                        let dy = ny - mouse_wy;
                        let dist = (dx * dx + dy * dy).sqrt();
                        if dist < best_dist {
                            best_dist = dist;
                            best_idx = Some(i);
                        }
                    }
                    if let Some(idx) = best_idx {
                        self.hovered_terrain_node = Some((td.object_index, idx));
                    }
                }

                for (i, &pt) in screen_pts.iter().enumerate() {
                    let is_hovered = self.hovered_terrain_node == Some((td.object_index, i));
                    let tex_idx = td.node_textures.get(i).copied().unwrap_or(0);
                    let base_color = if tex_idx == 1 {
                        crate::gpu2d::Color32::from_rgb(0x99, 0x66, 0x33) // brown = outline/splat1
                    } else {
                        crate::gpu2d::Color32::from_rgb(0x70, 0xB0, 0x30) // green = grass/splat0
                    };
                    let fill = if is_hovered {
                        crate::gpu2d::Color32::WHITE
                    } else {
                        base_color
                    };
                    let r = if is_hovered {
                        NODE_RADIUS + 2.0
                    } else {
                        NODE_RADIUS
                    };
                    let node_rect = crate::gpu2d::Rect::from_center_size(
                        pt,
                        crate::gpu2d::vec2(r * 2.0, r * 2.0),
                    );
                    painter.rect_filled(node_rect, 1.0, fill);
                    painter.rect_stroke(
                        node_rect,
                        1.0,
                        crate::gpu2d::Stroke::new(1.0, crate::gpu2d::Color32::BLACK),
                        crate::gpu2d::StrokeKind::Outside,
                    );
                }
            }
        }
    }

    /// Draw HUD overlays: origin axes, physics ground, level bounds, zoom info.
    pub(super) fn draw_hud(
        &self,
        painter: &crate::gpu2d::Painter,
        rect: crate::gpu2d::Rect,
        canvas_center: crate::gpu2d::Vec2,
        tr: &'static crate::i18n::locale::I18n,
    ) {
        // Origin axes
        let origin = self
            .camera
            .world_to_screen(Vec2 { x: 0.0, y: 0.0 }, canvas_center);
        if rect.contains(origin) {
            let axis_len = 30.0;
            painter.line_segment(
                [origin, crate::gpu2d::pos2(origin.x + axis_len, origin.y)],
                crate::gpu2d::Stroke::new(1.5, crate::gpu2d::Color32::from_rgb(255, 80, 80)),
            );
            painter.line_segment(
                [origin, crate::gpu2d::pos2(origin.x, origin.y - axis_len)],
                crate::gpu2d::Stroke::new(1.5, crate::gpu2d::Color32::from_rgb(80, 255, 80)),
            );
        }

        // Physics ground line
        if self.show_ground {
            const PHYSICS_GROUND_Y: f32 = -6.599;
            let ground_left = self.camera.world_to_screen(
                Vec2 {
                    x: -1000.0,
                    y: PHYSICS_GROUND_Y,
                },
                canvas_center,
            );
            let ground_right = self.camera.world_to_screen(
                Vec2 {
                    x: 1000.0,
                    y: PHYSICS_GROUND_Y,
                },
                canvas_center,
            );
            let left_x = ground_left.x.max(rect.left());
            let right_x = ground_right.x.min(rect.right());
            if left_x < right_x {
                let gy = ground_left.y;
                painter.line_segment(
                    [
                        crate::gpu2d::pos2(left_x, gy),
                        crate::gpu2d::pos2(right_x, gy),
                    ],
                    crate::gpu2d::Stroke::new(
                        1.0,
                        crate::gpu2d::Color32::from_rgba_unmultiplied(255, 165, 0, 180),
                    ),
                );
                painter.text(
                    crate::gpu2d::pos2(rect.left() + 8.0, gy - 14.0),
                    crate::gpu2d::Align2::LEFT_TOP,
                    format!("Y = {:.3}", PHYSICS_GROUND_Y),
                    crate::gpu2d::FontId::proportional(11.0),
                    crate::gpu2d::Color32::from_rgba_unmultiplied(255, 165, 0, 200),
                );
                painter.text(
                    crate::gpu2d::pos2(right_x - 8.0, gy - 14.0),
                    crate::gpu2d::Align2::RIGHT_TOP,
                    tr.get("menu_physics_ground"),
                    crate::gpu2d::FontId::proportional(11.0),
                    crate::gpu2d::Color32::from_rgba_unmultiplied(255, 165, 0, 200),
                );
            }
        }

        // Editable bounds overlays (drawn on top of everything)
        let draw_bounds = |target: crate::renderer::BoundsEditTarget,
                           vals: [f32; 4],
                           label_key: &str,
                           base_color: crate::gpu2d::Color32| {
            let [tl_x, tl_y, w, h] = vals;
            let p_tl = self
                .camera
                .world_to_screen(Vec2 { x: tl_x, y: tl_y }, canvas_center);
            let p_br = self.camera.world_to_screen(
                Vec2 {
                    x: tl_x + w,
                    y: tl_y - h,
                },
                canvas_center,
            );
            let bounds_rect = crate::gpu2d::Rect::from_two_pos(p_tl, p_br);
            let clipped = bounds_rect.intersect(rect);
            if clipped.width() <= 0.0 || clipped.height() <= 0.0 {
                return;
            }

            let edit_enabled = self.show_preview_route;
            let is_dragging = self
                .bounds_dragging
                .as_ref()
                .is_some_and(|drag| drag.target == target);
            let is_hovered = self
                .bounds_hovered_handle
                .is_some_and(|hit| hit.target == target);
            let color = if is_dragging {
                crate::gpu2d::Color32::from_rgba_unmultiplied(255, 255, 100, 220)
            } else if is_hovered {
                crate::gpu2d::Color32::from_rgba_unmultiplied(255, 220, 50, 220)
            } else {
                base_color
            };
            let stroke_w = if is_dragging || is_hovered { 2.5 } else { 2.0 };
            painter.rect_stroke(
                bounds_rect,
                0.0,
                crate::gpu2d::Stroke::new(stroke_w, color),
                crate::gpu2d::StrokeKind::Inside,
            );

            if edit_enabled && (is_hovered || is_dragging) {
                let hs = 4.0;
                let handle_fill = crate::gpu2d::Color32::from_rgba_unmultiplied(
                    color.r(),
                    color.g(),
                    color.b(),
                    200,
                );
                let handle_stroke = crate::gpu2d::Stroke::new(
                    1.0,
                    crate::gpu2d::Color32::from_rgba_unmultiplied(40, 40, 40, 220),
                );
                let cx = (bounds_rect.left() + bounds_rect.right()) / 2.0;
                let cy = (bounds_rect.top() + bounds_rect.bottom()) / 2.0;
                for pos in [
                    bounds_rect.left_top(),
                    bounds_rect.right_top(),
                    bounds_rect.left_bottom(),
                    bounds_rect.right_bottom(),
                ] {
                    let r = crate::gpu2d::Rect::from_center_size(
                        pos,
                        crate::gpu2d::vec2(hs * 2.0, hs * 2.0),
                    );
                    painter.rect(
                        r,
                        0.0,
                        handle_fill,
                        handle_stroke,
                        crate::gpu2d::StrokeKind::Inside,
                    );
                }
                for pos in [
                    crate::gpu2d::pos2(cx, bounds_rect.top()),
                    crate::gpu2d::pos2(cx, bounds_rect.bottom()),
                    crate::gpu2d::pos2(bounds_rect.left(), cy),
                    crate::gpu2d::pos2(bounds_rect.right(), cy),
                ] {
                    let r = crate::gpu2d::Rect::from_center_size(
                        pos,
                        crate::gpu2d::vec2(hs * 2.0, hs * 2.0),
                    );
                    painter.rect(
                        r,
                        0.0,
                        handle_fill,
                        handle_stroke,
                        crate::gpu2d::StrokeKind::Inside,
                    );
                }
            }

            painter.text(
                crate::gpu2d::pos2(bounds_rect.left() + 4.0, bounds_rect.top() - 16.0),
                crate::gpu2d::Align2::LEFT_TOP,
                tr.get(label_key),
                crate::gpu2d::FontId::proportional(11.0),
                color,
            );
            painter.text(
                crate::gpu2d::pos2(bounds_rect.left() + 4.0, bounds_rect.top() + 2.0),
                crate::gpu2d::Align2::LEFT_TOP,
                format!("({:.1}, {:.1}) {}x{}", tl_x, tl_y, w, h),
                crate::gpu2d::FontId::proportional(11.0),
                color,
            );
        };

        let route_node_fill = |target: crate::renderer::RouteNodeTarget,
                               normal: crate::gpu2d::Color32,
                               hovered: crate::gpu2d::Color32| {
            let is_dragging = self
                .route_node_dragging
                .as_ref()
                .is_some_and(|drag| drag.target == target);
            let is_hovered = self.show_preview_route && self.route_node_hovered == Some(target);
            if is_dragging {
                crate::gpu2d::Color32::from_rgba_unmultiplied(255, 255, 120, 235)
            } else if is_hovered {
                hovered
            } else {
                normal
            }
        };

        let route_node_radius = |target: crate::renderer::RouteNodeTarget, base: f32| {
            let active = self
                .route_node_dragging
                .as_ref()
                .is_some_and(|drag| drag.target == target)
                || (self.show_preview_route && self.route_node_hovered == Some(target));
            if active { base + 1.5 } else { base }
        };

        if self.show_preview_route {
            if let Some(ref route_points) = self.custom_preview_route {
                if let Some(vals) = self.camera_limits {
                    draw_bounds(
                        crate::renderer::BoundsEditTarget::CameraLimits,
                        vals,
                        "prop_camera_limits",
                        crate::gpu2d::Color32::from_rgba_unmultiplied(255, 200, 0, 180),
                    );
                }
                if let Some(vals) = self.construction_view_bounds {
                    draw_bounds(
                        crate::renderer::BoundsEditTarget::ConstructionView,
                        vals,
                        "prop_build_view_bounds",
                        crate::gpu2d::Color32::from_rgba_unmultiplied(90, 230, 120, 180),
                    );
                }

                if self.show_preview_route && route_points.len() >= 2 {
                    let sampled = sample_bple_sandbox_route(route_points);
                    let mut screen_pts = Vec::with_capacity(sampled.len());
                    for p in sampled {
                        screen_pts.push(self.camera.world_to_screen(p, canvas_center));
                    }
                    draw_dashed_polyline(
                        painter,
                        &screen_pts,
                        crate::gpu2d::Stroke::new(
                            2.0,
                            crate::gpu2d::Color32::from_rgba_unmultiplied(140, 230, 255, 210),
                        ),
                        8.0,
                        6.0,
                    );
                    if screen_pts.len() >= 2 {
                        draw_arrow_head(
                            painter,
                            screen_pts[1],
                            screen_pts[0],
                            crate::gpu2d::Stroke::new(
                                2.0,
                                crate::gpu2d::Color32::from_rgba_unmultiplied(140, 230, 255, 220),
                            ),
                        );
                    }
                }

                for (i, &world_pt) in route_points.iter().enumerate() {
                    let screen = self.camera.world_to_screen(world_pt, canvas_center);
                    let target = crate::renderer::RouteNodeTarget::CustomPreview(i);
                    draw_route_node(
                        painter,
                        screen,
                        route_node_radius(target, 5.0),
                        route_node_fill(
                            target,
                            crate::gpu2d::Color32::from_rgba_unmultiplied(140, 230, 255, 230),
                            crate::gpu2d::Color32::from_rgba_unmultiplied(200, 245, 255, 240),
                        ),
                        crate::gpu2d::Stroke::new(
                            1.5,
                            crate::gpu2d::Color32::from_rgba_unmultiplied(20, 70, 90, 220),
                        ),
                        &(i + 1).to_string(),
                    );
                }
            } else {
                if let Some(vals) = self.initial_view_bounds {
                    draw_bounds(
                        crate::renderer::BoundsEditTarget::InitialView,
                        vals,
                        "prop_goal_area_view",
                        crate::gpu2d::Color32::from_rgba_unmultiplied(90, 195, 255, 180),
                    );
                }
                if let Some(vals) = self.camera_limits {
                    draw_bounds(
                        crate::renderer::BoundsEditTarget::CameraLimits,
                        vals,
                        "prop_camera_limits",
                        crate::gpu2d::Color32::from_rgba_unmultiplied(255, 200, 0, 180),
                    );
                }
                if let Some(vals) = self.construction_view_bounds {
                    draw_bounds(
                        crate::renderer::BoundsEditTarget::ConstructionView,
                        vals,
                        "prop_build_view_bounds",
                        crate::gpu2d::Color32::from_rgba_unmultiplied(90, 230, 120, 180),
                    );
                }

                if let (Some(initial_bounds), Some(level_bounds), Some(build_bounds)) = (
                    self.initial_view_bounds,
                    self.camera_limits,
                    self.construction_view_bounds,
                ) {
                    let logical_route = [
                        bounds_center(initial_bounds),
                        bounds_center(level_bounds),
                        bounds_center(build_bounds),
                    ];

                    if self.show_preview_route {
                        let sampled = sample_bple_preview_route(&logical_route);
                        let mut screen_pts = Vec::with_capacity(sampled.len());
                        for p in sampled {
                            screen_pts.push(self.camera.world_to_screen(p, canvas_center));
                        }
                        draw_dashed_polyline(
                            painter,
                            &screen_pts,
                            crate::gpu2d::Stroke::new(
                                2.0,
                                crate::gpu2d::Color32::from_rgba_unmultiplied(140, 230, 255, 210),
                            ),
                            8.0,
                            6.0,
                        );

                        if let Some(tip) = screen_pts.last().copied()
                            && screen_pts.len() >= 2
                        {
                            let from = screen_pts[screen_pts.len() - 2];
                            draw_arrow_head(
                                painter,
                                tip,
                                from,
                                crate::gpu2d::Stroke::new(
                                    2.0,
                                    crate::gpu2d::Color32::from_rgba_unmultiplied(
                                        140, 230, 255, 220,
                                    ),
                                ),
                            );
                        }
                    }

                    let initial_screen =
                        self.camera.world_to_screen(logical_route[0], canvas_center);
                    let middle_screen =
                        self.camera.world_to_screen(logical_route[1], canvas_center);
                    let build_screen = self.camera.world_to_screen(logical_route[2], canvas_center);
                    let initial_target = crate::renderer::RouteNodeTarget::InitialView;
                    let middle_target = crate::renderer::RouteNodeTarget::CameraLimits;
                    let build_target = crate::renderer::RouteNodeTarget::ConstructionView;
                    draw_route_node(
                        painter,
                        initial_screen,
                        route_node_radius(initial_target, 5.0),
                        route_node_fill(
                            initial_target,
                            crate::gpu2d::Color32::from_rgba_unmultiplied(210, 245, 255, 230),
                            crate::gpu2d::Color32::from_rgba_unmultiplied(240, 250, 255, 240),
                        ),
                        crate::gpu2d::Stroke::new(
                            1.0,
                            crate::gpu2d::Color32::from_rgba_unmultiplied(20, 70, 90, 220),
                        ),
                        &tr.get("prop_goal_area_view"),
                    );
                    draw_route_node(
                        painter,
                        middle_screen,
                        route_node_radius(middle_target, 6.5),
                        route_node_fill(
                            middle_target,
                            crate::gpu2d::Color32::from_rgba_unmultiplied(255, 220, 60, 235),
                            crate::gpu2d::Color32::from_rgba_unmultiplied(255, 238, 120, 240),
                        ),
                        crate::gpu2d::Stroke::new(
                            2.0,
                            crate::gpu2d::Color32::from_rgba_unmultiplied(80, 55, 0, 235),
                        ),
                        "2",
                    );
                    draw_route_node(
                        painter,
                        build_screen,
                        route_node_radius(build_target, 4.5),
                        route_node_fill(
                            build_target,
                            crate::gpu2d::Color32::from_rgba_unmultiplied(120, 240, 150, 230),
                            crate::gpu2d::Color32::from_rgba_unmultiplied(180, 248, 190, 238),
                        ),
                        crate::gpu2d::Stroke::new(
                            1.0,
                            crate::gpu2d::Color32::from_rgba_unmultiplied(20, 80, 35, 220),
                        ),
                        "3",
                    );
                }
            }
        }

        // Zoom + theme info
        let theme_label = self
            .bg_theme
            .map(|s| s.to_owned())
            .unwrap_or_else(|| tr.get("hud_unknown_theme"));
        painter.text(
            rect.right_top() + crate::gpu2d::vec2(-8.0, 8.0),
            crate::gpu2d::Align2::RIGHT_TOP,
            format!(
                "{}: {:.1}x  {}: {}",
                tr.get("hud_zoom"),
                self.camera.zoom,
                tr.get("hud_theme"),
                theme_label
            ),
            crate::gpu2d::FontId::proportional(12.0),
            crate::gpu2d::Color32::from_rgb(150, 150, 150),
        );
    }

    /// Lazy-load atlas textures (only attempt once per atlas).
    pub(super) fn lazy_load_textures(&mut self, ctx: &crate::gpu2d::Context) {
        // Sprite atlases (sprites/, props/, and Texture2D/ subdirs)
        for atlas in ATLAS_FILES {
            if self.tex_cache.get(atlas).is_none() {
                let sprite_key = format!("Assets/Texture2D/{}", atlas);
                let props_key = format!("Assets/Texture2D/{}", atlas);
                if self
                    .tex_cache
                    .load_texture(ctx, &sprite_key, atlas)
                    .is_none()
                    && self
                        .tex_cache
                        .load_texture(ctx, &props_key, atlas)
                        .is_none()
                {
                    self.tex_cache
                        .load_texture(ctx, &format!("Assets/Texture2D/{}", atlas), atlas);
                }
            }
        }
        // Background atlases (bg/ subdir)
        for atlas in crate::data::bg_data::bg_atlas_files() {
            if self.tex_cache.get(atlas).is_none() {
                self.tex_cache
                    .load_texture(ctx, &format!("Assets/Texture2D/{}", atlas), atlas);
            }
        }
        // Sky textures (sky/ subdir)
        for sky in crate::data::bg_data::sky_texture_files() {
            if self.tex_cache.get(sky).is_none() {
                self.tex_cache
                    .load_texture(ctx, &format!("Assets/Texture2D/{}", sky), sky);
            }
        }
        // Terrain textures — usually Texture2D/ground, with a few Resources/* fallbacks.
        for td in &self.terrain_data {
            if let Some(ref tex_name) = td.fill_texture
                && self.tex_cache.get(tex_name).is_none()
                && let Some(asset_key) = assets::terrain_texture_asset_key(tex_name)
            {
                self.tex_cache
                    .load_texture_repeat(ctx, &asset_key, tex_name);
            }
        }
        // Goal flag texture (props/ subdir) — repeat wrap + flip V for UV scroll
        if self.tex_cache.get(GOAL_FLAG_TEXTURE).is_none() {
            self.tex_cache.load_texture_repeat_flipv(
                ctx,
                &format!("Assets/Texture2D/{}", GOAL_FLAG_TEXTURE),
                GOAL_FLAG_TEXTURE,
            );
        }
        for texture_name in [
            particles::zzz_particle_texture_name(),
            particles::fan_particle_texture_name(),
            particles::wind_particle_texture_name(),
        ]
        .into_iter()
        .flatten()
        {
            if self.tex_cache.get(texture_name).is_none() {
                self.tex_cache.load_texture(
                    ctx,
                    &format!("Assets/Texture2D/{}", texture_name),
                    texture_name,
                );
            }
        }

        if self.tex_cache.get(GLOW_ATLAS).is_none() {
            self.tex_cache.load_texture(
                ctx,
                &format!("Assets/Texture2D/{}", GLOW_ATLAS),
                GLOW_ATLAS,
            );
        }
    }

    /// Draw adaptive world grid overlay.
    pub(super) fn draw_grid(
        &self,
        painter: &crate::gpu2d::Painter,
        rect: crate::gpu2d::Rect,
        canvas_center: crate::gpu2d::Vec2,
    ) {
        let target_px = 60.0;
        let base = target_px / self.camera.zoom;
        let nice = [
            0.1, 0.2, 0.5, 1.0, 2.0, 5.0, 10.0, 20.0, 50.0, 100.0, 200.0, 500.0,
        ];
        let grid_step = nice
            .iter()
            .copied()
            .min_by(|a, b| (a - base).abs().total_cmp(&(b - base).abs()))
            .unwrap_or(5.0);
        let color = crate::gpu2d::Color32::from_rgba_unmultiplied(255, 255, 255, 25);

        let tl = self.camera.screen_to_world(rect.left_top(), canvas_center);
        let br = self
            .camera
            .screen_to_world(rect.right_bottom(), canvas_center);

        let min_x = tl.x.min(br.x);
        let max_x = tl.x.max(br.x);
        let min_y = tl.y.min(br.y);
        let max_y = tl.y.max(br.y);

        let start_x = (min_x / grid_step).floor() as i32;
        let end_x = (max_x / grid_step).ceil() as i32;
        for ix in start_x..=end_x {
            let wx = ix as f32 * grid_step;
            let screen_x = self
                .camera
                .world_to_screen(Vec2 { x: wx, y: 0.0 }, canvas_center)
                .x;
            let x = snap_grid_line_to_pixel_center(screen_x);
            painter.line_segment(
                [
                    crate::gpu2d::pos2(x, rect.top()),
                    crate::gpu2d::pos2(x, rect.bottom()),
                ],
                crate::gpu2d::Stroke::new(GRID_LINE_WIDTH, color),
            );
        }

        let start_y = (min_y / grid_step).floor() as i32;
        let end_y = (max_y / grid_step).ceil() as i32;
        for iy in start_y..=end_y {
            let wy = iy as f32 * grid_step;
            let screen_y = self
                .camera
                .world_to_screen(Vec2 { x: 0.0, y: wy }, canvas_center)
                .y;
            let y = snap_grid_line_to_pixel_center(screen_y);
            painter.line_segment(
                [
                    crate::gpu2d::pos2(rect.left(), y),
                    crate::gpu2d::pos2(rect.right(), y),
                ],
                crate::gpu2d::Stroke::new(GRID_LINE_WIDTH, color),
            );
        }
    }

    /// Draw tool-mode overlays: box-select rectangle, terrain draw preview.
    pub(super) fn draw_tool_overlay(
        &self,
        painter: &crate::gpu2d::Painter,
        canvas_center: crate::gpu2d::Vec2,
        cursor_mode: CursorMode,
    ) {
        match cursor_mode {
            CursorMode::BoxSelect => {
                // Draw the active box-selection rectangle
                if let Some(start) = self.box_select_start
                    && let Some(end) = painter.ctx().input(|i| i.pointer.latest_pos())
                {
                    let rect = crate::gpu2d::Rect::from_two_pos(start, end);
                    let fill = crate::gpu2d::Color32::from_rgba_unmultiplied(80, 140, 255, 40);
                    let stroke = crate::gpu2d::Stroke::new(
                        1.0,
                        crate::gpu2d::Color32::from_rgb(80, 140, 255),
                    );
                    painter.rect(rect, 0.0, fill, stroke, crate::gpu2d::StrokeKind::Inside);
                }
            }
            CursorMode::DrawTerrain => {
                if let Some(preview_points) = self.terrain_preset_preview_points() {
                    let color = crate::gpu2d::Color32::from_rgb(100, 220, 100);
                    let points: Vec<crate::gpu2d::Pos2> = preview_points
                        .iter()
                        .map(|p| self.camera.world_to_screen(*p, canvas_center))
                        .collect();

                    for pair in points.windows(2) {
                        painter.line_segment(
                            [pair[0], pair[1]],
                            crate::gpu2d::Stroke::new(2.0, color),
                        );
                    }

                    for pt in points.iter().step_by(4.max(points.len() / 8)) {
                        painter.circle_filled(*pt, 3.0, color);
                    }
                }

                // Draw the point-by-point terrain preview
                if self.active_terrain_preset().is_none() && !self.draw_terrain_points.is_empty() {
                    let color = crate::gpu2d::Color32::from_rgb(100, 220, 100);
                    let close_color = crate::gpu2d::Color32::from_rgb(255, 200, 60);
                    let continuation_color = crate::gpu2d::Color32::from_rgb(80, 170, 255);
                    let points: Vec<crate::gpu2d::Pos2> = self
                        .draw_terrain_points
                        .iter()
                        .map(|p| self.camera.world_to_screen(*p, canvas_center))
                        .collect();

                    // Draw lines between placed points
                    for pair in points.windows(2) {
                        painter.line_segment(
                            [pair[0], pair[1]],
                            crate::gpu2d::Stroke::new(2.0, color),
                        );
                    }

                    // Draw dots at each placed point
                    for pt in &points {
                        painter.circle_filled(*pt, 3.5, color);
                    }

                    // When only one point exists while active, this point is a
                    // continuation anchor from the previous stroke endpoint.
                    if self.draw_terrain_active && points.len() == 1 {
                        painter.circle_stroke(
                            points[0],
                            7.0,
                            crate::gpu2d::Stroke::new(2.0, continuation_color),
                        );
                    }

                    // Highlight first point when closeable (≥3 points) in polyline modes
                    if !matches!(
                        self.terrain_draw_mode,
                        super::TerrainDrawMode::Curve | super::TerrainDrawMode::CircularArc
                    ) && points.len() >= 3
                    {
                        painter.circle_stroke(
                            points[0],
                            8.0,
                            crate::gpu2d::Stroke::new(2.0, close_color),
                        );
                    }

                    // Draw preview for current draw mode
                    if self.draw_terrain_active
                        && let Some(mouse) = painter.ctx().input(|i| i.pointer.latest_pos())
                    {
                        let dash_color =
                            crate::gpu2d::Color32::from_rgba_unmultiplied(100, 220, 100, 140);
                        if matches!(
                            self.terrain_draw_mode,
                            super::TerrainDrawMode::Curve | super::TerrainDrawMode::CircularArc
                        ) {
                            if self.draw_terrain_points.len() == 2 {
                                let start = self.draw_terrain_points[0];
                                let end = self.draw_terrain_points[1];
                                let control = self.camera.screen_to_world(mouse, canvas_center);
                                let nodes = self.terrain_curve_segments.clamp(3, 256);
                                let sampled_world = if self.terrain_draw_mode
                                    == super::TerrainDrawMode::CircularArc
                                {
                                    sample_circular_arc_preview(start, control, end, nodes)
                                        .unwrap_or_else(|| {
                                            let mut world_points = Vec::with_capacity(nodes);
                                            let denom = (nodes - 1) as f32;
                                            for i in 0..nodes {
                                                let t = i as f32 / denom;
                                                let omt = 1.0 - t;
                                                world_points.push(Vec2 {
                                                    x: omt * omt * start.x
                                                        + 2.0 * omt * t * control.x
                                                        + t * t * end.x,
                                                    y: omt * omt * start.y
                                                        + 2.0 * omt * t * control.y
                                                        + t * t * end.y,
                                                });
                                            }
                                            world_points
                                        })
                                } else {
                                    let mut world_points = Vec::with_capacity(nodes);
                                    let denom = (nodes - 1) as f32;
                                    for i in 0..nodes {
                                        let t = i as f32 / denom;
                                        let omt = 1.0 - t;
                                        world_points.push(Vec2 {
                                            x: omt * omt * start.x
                                                + 2.0 * omt * t * control.x
                                                + t * t * end.x,
                                            y: omt * omt * start.y
                                                + 2.0 * omt * t * control.y
                                                + t * t * end.y,
                                        });
                                    }
                                    world_points
                                };

                                let sampled: Vec<crate::gpu2d::Pos2> = sampled_world
                                    .iter()
                                    .map(|world| self.camera.world_to_screen(*world, canvas_center))
                                    .collect();
                                for pair in sampled.windows(2) {
                                    painter.line_segment(
                                        [pair[0], pair[1]],
                                        crate::gpu2d::Stroke::new(1.5, dash_color),
                                    );
                                }

                                let control_screen =
                                    self.camera.world_to_screen(control, canvas_center);
                                painter.circle_stroke(
                                    control_screen,
                                    6.0,
                                    crate::gpu2d::Stroke::new(
                                        2.0,
                                        crate::gpu2d::Color32::from_rgb(255, 210, 80),
                                    ),
                                );

                                if self.terrain_draw_mode == super::TerrainDrawMode::CircularArc
                                    && let Some(center) =
                                        circle_center_from_three_points(start, control, end)
                                {
                                    let center_screen =
                                        self.camera.world_to_screen(center, canvas_center);
                                    painter.circle_filled(
                                        center_screen,
                                        3.5,
                                        crate::gpu2d::Color32::from_rgb(80, 170, 255),
                                    );
                                    painter.line_segment(
                                        [center_screen, control_screen],
                                        crate::gpu2d::Stroke::new(
                                            1.0,
                                            crate::gpu2d::Color32::from_rgba_unmultiplied(
                                                80, 170, 255, 140,
                                            ),
                                        ),
                                    );
                                }
                            }
                        } else if let Some(&last) = points.last() {
                            let preview_mouse = {
                                let mouse_world = self.camera.screen_to_world(mouse, canvas_center);
                                let constrained_world = match self.terrain_draw_mode {
                                    super::TerrainDrawMode::Curve
                                    | super::TerrainDrawMode::CircularArc => mouse_world,
                                    super::TerrainDrawMode::Free => mouse_world,
                                    super::TerrainDrawMode::Horizontal => Vec2 {
                                        x: mouse_world.x,
                                        y: self
                                            .draw_terrain_points
                                            .last()
                                            .map(|p| p.y)
                                            .unwrap_or(mouse_world.y),
                                    },
                                    super::TerrainDrawMode::Vertical => Vec2 {
                                        x: self
                                            .draw_terrain_points
                                            .last()
                                            .map(|p| p.x)
                                            .unwrap_or(mouse_world.x),
                                        y: mouse_world.y,
                                    },
                                };
                                self.camera
                                    .world_to_screen(constrained_world, canvas_center)
                            };
                            painter.line_segment(
                                [last, preview_mouse],
                                crate::gpu2d::Stroke::new(1.0, dash_color),
                            );
                        }

                        // If near first point and ≥3 points, show closing preview
                        if !matches!(
                            self.terrain_draw_mode,
                            super::TerrainDrawMode::Curve | super::TerrainDrawMode::CircularArc
                        ) && points.len() >= 3
                        {
                            let first_screen = points[0];
                            let dx = mouse.x - first_screen.x;
                            let dy = mouse.y - first_screen.y;
                            if dx * dx + dy * dy < 12.0 * 12.0 {
                                painter.circle_filled(
                                    first_screen,
                                    8.0,
                                    crate::gpu2d::Color32::from_rgba_unmultiplied(255, 200, 60, 80),
                                );
                            }
                        }
                    }
                }
            }
            _ => {}
        }
    }
}

#[cfg(test)]
mod tests {
    use super::{GRID_LINE_WIDTH, snap_grid_line_to_pixel_center};

    #[test]
    fn grid_lines_are_one_pixel_wide_and_snap_to_pixel_centers() {
        assert_eq!(GRID_LINE_WIDTH, 1.0);

        for coordinate in [-42.000004, -0.01, 0.0, 0.49, 0.51, 41.999996, 314.75] {
            let snapped = snap_grid_line_to_pixel_center(coordinate);
            assert_eq!(snapped - snapped.floor(), 0.5);
            assert!((snapped - coordinate).abs() <= 0.5);
        }
    }
}
