//! Wind area particle systems: spawn, update, draw.

use std::collections::HashMap;
use std::sync::OnceLock;

use crate::data::assets;
use crate::data::unity_particles;
use crate::data::unity_particles::{ParticleCurve, UnityParticleSystemDef};
use crate::domain::prefab_asset::PrefabAssetDocument;
use crate::domain::types::{Vec2, Vec3};
use crate::unity_runtime::components::{BoxCollider, ParticleSystem, Transform, WindArea};
use crate::unity_runtime::scene::Scene;

use super::super::DrawCtx;
use super::{LevelRenderer, particle_sheet_uv_rect, pseudo_random, rotate_vec2};

/// Wind area zone definition.
#[derive(Clone, Debug)]
pub(crate) struct WindAreaDef {
    pub sprite_index: usize,
    pub center_x: f32,
    pub center_y: f32,
    pub render_z: f32,
    pub half_w: f32,
    pub half_h: f32,
    pub local_dir_x: f32,
    pub local_dir_y: f32,
    pub dir_x: f32,
    pub dir_y: f32,
    pub power_factor: f32,
    pub systems: Vec<UnityParticleSystemDef>,
}

const WIND_AREA_PREFAB_ASSET: &str = "Assets/Prefab/WindArea.prefab";
const WIND_EMISSION_SPAWN_EPSILON: f32 = 1e-4;

#[derive(Clone, Copy)]
struct WindAreaPrefabDefaults {
    box_size: Vec3,
    local_dir: Vec2,
    power_factor: f32,
}

#[derive(Default)]
struct WindAreaOverrideData {
    box_size: Option<Vec3>,
    handle_world: Option<Vec3>,
    power_factor: Option<f32>,
    systems: HashMap<String, WindAreaSystemOverrides>,
}

#[derive(Default)]
struct WindAreaSystemOverrides {
    local_position: Option<Vec3>,
    local_rotation: Option<[f32; 4]>,
    start_lifetime_scalar: Option<f32>,
    start_speed_scalar: Option<f32>,
    emission_rate_scalar: Option<f32>,
}

/// A single wind leaf particle.
pub(crate) struct WindParticle {
    pub x: f32,
    pub y: f32,
    pub vx: f32,
    pub vy: f32,
    pub side_x: f32,
    pub side_y: f32,
    pub age: f32,
    pub lifetime: f32,
    pub rot: f32,
    pub rot_speed: f32,
    pub size: f32,
    /// Sheet column chosen by the prefab UV module.
    pub leaf_col: u8,
    pub source_sprite_index: usize,
    pub source_system_index: usize,
}

fn wind_area_prefab() -> &'static unity_particles::WindAreaParticlePrefab {
    unity_particles::wind_area_prefab().expect("WindArea particle prefab should be available")
}

fn wind_area_particle_systems() -> &'static [UnityParticleSystemDef] {
    &wind_area_prefab().systems
}

fn default_wind_area_systems() -> Vec<UnityParticleSystemDef> {
    wind_area_particle_systems().to_vec()
}

pub(crate) fn wind_area_particle_system_count() -> usize {
    wind_area_particle_systems().len()
}

pub(crate) fn wind_particle_texture_name() -> Option<&'static str> {
    let prefab = unity_particles::wind_area_prefab()?;
    let texture_name = prefab.systems.first()?.texture_name()?;
    prefab
        .systems
        .iter()
        .all(|system| system.texture_name() == Some(texture_name))
        .then_some(texture_name)
}

fn wind_area_particle_system(
    area: &WindAreaDef,
    system_index: usize,
) -> &unity_particles::UnityParticleSystemDef {
    &area.systems[system_index]
}

fn wind_area_particle_spawn_rate(area: &WindAreaDef, system_index: usize) -> f32 {
    let system = wind_area_particle_system(area, system_index);
    if !system.play_on_awake && !system.looping {
        0.0
    } else {
        system.emission_rate.sample(0.0, 0.0)
    }
}

fn wind_area_particle_max_count(area: &WindAreaDef, system_index: usize) -> usize {
    wind_area_particle_system(area, system_index).max_particles
}

pub(crate) fn wind_area_local_direction() -> Vec2 {
    wind_area_prefab_defaults().local_dir
}

fn wind_area_prefab_defaults() -> WindAreaPrefabDefaults {
    static DEFAULTS: OnceLock<WindAreaPrefabDefaults> = OnceLock::new();

    *DEFAULTS.get_or_init(load_wind_area_prefab_defaults)
}

fn load_wind_area_prefab_defaults() -> WindAreaPrefabDefaults {
    let text = assets::read_pathname_text(WIND_AREA_PREFAB_ASSET)
        .expect("WindArea.prefab should load from embedded assets");
    let prefab = PrefabAssetDocument::parse(&text)
        .expect("WindArea.prefab should parse from embedded assets");
    let box_size = prefab
        .root_component("BoxCollider")
        .expect("WindArea.prefab must include a root BoxCollider")
        .field_vec3("m_Size")
        .map(|size| Vec3 {
            x: size[0],
            y: size[1],
            z: size[2],
        })
        .expect("WindArea.prefab BoxCollider must include m_Size");
    let wind_area = prefab
        .root_component("WindArea")
        .expect("WindArea.prefab must include a root WindArea component");
    let power_factor = wind_area
        .field_f32("m_windPowerFactor")
        .expect("WindArea.prefab WindArea component must include m_windPowerFactor");
    let handle = wind_area
        .field_vec3("windDirectionHandle")
        .expect("WindArea.prefab WindArea component must include windDirectionHandle");
    let root_transform = prefab
        .root_transform()
        .expect("WindArea.prefab must include a root Transform");
    let local_dir = normalize_vec2(Vec2 {
        x: handle[0] - root_transform.local_pos[0],
        y: handle[1] - root_transform.local_pos[1],
    });
    if local_dir.x == 0.0 && local_dir.y == 0.0 {
        panic!("WindArea.prefab windDirectionHandle must define a non-zero local direction");
    }

    WindAreaPrefabDefaults {
        box_size,
        local_dir,
        power_factor,
    }
}

fn wind_particle_emitter_offsets(area: &WindAreaDef, system_index: usize) -> (f32, f32) {
    let system = wind_area_particle_system(area, system_index);
    let dir = Vec2 {
        x: area.local_dir_x,
        y: area.local_dir_y,
    };
    let side = Vec2 {
        x: -dir.y,
        y: dir.x,
    };
    let local = Vec2 {
        x: system.local_position.x,
        y: system.local_position.y,
    };
    (dot2(local, dir), dot2(local, side))
}

fn wind_particle_shape_spawn_offset(area: &WindAreaDef, system_index: usize, seed: u32) -> Vec2 {
    let system = wind_area_particle_system(area, system_index);
    let axis_x = system.shape_scale.x.abs() * system.shape_radius;
    let axis_y = system.shape_scale.y.abs() * system.shape_radius;
    let axis_z = system.shape_scale.z.abs() * system.shape_radius;
    let right = system.projected_right_xy();
    let up = system.projected_up_xy();
    let forward = system.projected_forward_xy();

    for attempt in 0..8u32 {
        let local_x =
            pseudo_random(seed.wrapping_mul(17).wrapping_add(1 + attempt * 3)) * 2.0 - 1.0;
        let local_y =
            pseudo_random(seed.wrapping_mul(19).wrapping_add(2 + attempt * 3)) * 2.0 - 1.0;
        let local_z =
            pseudo_random(seed.wrapping_mul(23).wrapping_add(3 + attempt * 3)) * 2.0 - 1.0;
        if local_x * local_x + local_y * local_y + local_z * local_z > 1.0 {
            continue;
        }
        return Vec2 {
            x: right.x * local_x * axis_x + up.x * local_y * axis_y + forward.x * local_z * axis_z,
            y: right.y * local_x * axis_x + up.y * local_y * axis_y + forward.y * local_z * axis_z,
        };
    }

    let fallback_x = pseudo_random(seed.wrapping_mul(29).wrapping_add(5)) * 2.0 - 1.0;
    let fallback_y = pseudo_random(seed.wrapping_mul(31).wrapping_add(7)) * 2.0 - 1.0;
    let fallback_z = pseudo_random(seed.wrapping_mul(37).wrapping_add(11)) * 2.0 - 1.0;
    Vec2 {
        x: right.x * fallback_x * axis_x
            + up.x * fallback_y * axis_y
            + forward.x * fallback_z * axis_z,
        y: right.y * fallback_x * axis_x
            + up.y * fallback_y * axis_y
            + forward.y * fallback_z * axis_z,
    }
}

fn wind_particle_lifetime(area: &WindAreaDef, system_index: usize, random: f32) -> f32 {
    wind_area_particle_system(area, system_index)
        .start_lifetime
        .sample(0.0, random)
}

fn wind_particle_start_speed(area: &WindAreaDef, system_index: usize, random: f32) -> f32 {
    wind_area_particle_system(area, system_index)
        .start_speed
        .sample(0.0, random)
}

fn wind_particle_start_size(area: &WindAreaDef, system_index: usize, random: f32) -> f32 {
    wind_area_particle_system(area, system_index)
        .start_size
        .sample(0.0, random)
}

fn wind_particle_start_rotation(area: &WindAreaDef, system_index: usize, random: f32) -> f32 {
    wind_area_particle_system(area, system_index)
        .start_rotation
        .sample(0.0, random)
}

fn wind_particle_rotation_speed(area: &WindAreaDef, system_index: usize, random: f32) -> f32 {
    wind_area_particle_system(area, system_index)
        .rotation_over_lifetime
        .sample(0.0, random)
}

fn wind_particle_uv_column(area: &WindAreaDef, system_index: usize, random: f32) -> u8 {
    wind_area_particle_system(area, system_index)
        .uv_module
        .sample_frame_index(random) as u8
}

fn wind_particle_uv_layout(area: &WindAreaDef, system_index: usize) -> (f32, f32, u32) {
    let system = wind_area_particle_system(area, system_index);
    (
        system.uv_module.tiles_x as f32,
        system.uv_module.tiles_y as f32,
        system.uv_module.row_index,
    )
}

fn dot2(lhs: Vec2, rhs: Vec2) -> f32 {
    lhs.x * rhs.x + lhs.y * rhs.y
}

fn normalize_vec2(vec: Vec2) -> Vec2 {
    let len = (vec.x * vec.x + vec.y * vec.y).sqrt();
    if len <= f32::EPSILON {
        return Vec2 { x: 0.0, y: 0.0 };
    }
    Vec2 {
        x: vec.x / len,
        y: vec.y / len,
    }
}

fn parse_wind_area_overrides(raw_text: Option<&str>) -> WindAreaOverrideData {
    let Some(text) = raw_text else {
        return WindAreaOverrideData::default();
    };
    let Some((scene, root)) = Scene::from_override_text(text) else {
        return WindAreaOverrideData::default();
    };

    let mut result = WindAreaOverrideData::default();

    if let Some((_, bc)) = scene.get_component_of::<BoxCollider>(root) {
        result.box_size = bc.size;
    }
    if let Some((_, wa)) = scene.get_component_of::<WindArea>(root) {
        result.handle_world = wa.wind_direction_handle;
        result.power_factor = wa.wind_power_factor;
    }

    for &child_id in &scene.game_object(root).children.clone() {
        let child_name = scene.game_object(child_id).name.clone();
        if !child_name.starts_with("WindEffect") {
            continue;
        }

        let mut system = WindAreaSystemOverrides::default();
        if let Some((_, t)) = scene.get_component_of::<Transform>(child_id) {
            system.local_position = t.local_position;
            system.local_rotation = t.local_rotation.map(|q| [q.x, q.y, q.z, q.w]);
        }
        if let Some((_, ps)) = scene.get_component_of::<ParticleSystem>(child_id) {
            system.start_lifetime_scalar = ps.start_lifetime;
            system.start_speed_scalar = ps.start_speed;
            system.emission_rate_scalar = ps.emission_rate;
        }
        result.systems.insert(child_name, system);
    }

    result
}

fn apply_wind_area_system_override(
    system: &mut UnityParticleSystemDef,
    overrides: Option<&WindAreaSystemOverrides>,
    scale_x: f32,
    scale_y: f32,
) {
    if let Some(overrides) = overrides {
        if let Some(local_position) = overrides.local_position {
            system.local_position = local_position;
        }
        if let Some(local_rotation) = overrides.local_rotation {
            system.local_rotation = local_rotation;
        }
        if let Some(start_lifetime) = overrides.start_lifetime_scalar {
            system.start_lifetime = ParticleCurve::constant(start_lifetime);
        }
        if let Some(start_speed) = overrides.start_speed_scalar {
            system.start_speed = ParticleCurve::constant(start_speed);
        }
        if let Some(emission_rate) = overrides.emission_rate_scalar {
            system.emission_rate = ParticleCurve::constant(emission_rate);
        }
    }

    system.local_position.x *= scale_x;
    system.local_position.y *= scale_y;
    system.shape_scale.x *= scale_x.abs();
    system.shape_scale.y *= scale_y.abs();
}

fn wind_area_render_z(world_z: f32, systems: &[UnityParticleSystemDef]) -> f32 {
    let child_z = systems
        .iter()
        .map(|system| system.local_position.z)
        .fold(0.0, f32::min);
    world_z + child_z
}

pub(crate) fn build_wind_area_def(
    sprite_index: usize,
    center: Vec2,
    world_z: f32,
    rotation: f32,
    scale: Vec2,
    override_text: Option<&str>,
) -> WindAreaDef {
    let overrides = parse_wind_area_overrides(override_text);
    let defaults = wind_area_prefab_defaults();
    let default_local_dir = wind_area_local_direction();
    let local_dir = overrides
        .handle_world
        .map(|handle_world| {
            rotate_vec2(
                Vec2 {
                    x: handle_world.x - center.x,
                    y: handle_world.y - center.y,
                },
                -rotation,
            )
        })
        .map(normalize_vec2)
        .filter(|dir| dir.x != 0.0 || dir.y != 0.0)
        .unwrap_or(default_local_dir);
    let world_dir = rotate_vec2(local_dir, rotation);
    let box_size = overrides.box_size.unwrap_or(defaults.box_size);
    let mut systems = default_wind_area_systems();
    for system in &mut systems {
        apply_wind_area_system_override(
            system,
            overrides.systems.get(&system.name),
            scale.x,
            scale.y,
        );
    }

    WindAreaDef {
        sprite_index,
        center_x: center.x,
        center_y: center.y,
        render_z: wind_area_render_z(world_z, &systems),
        half_w: box_size.x.abs() * 0.5 * scale.x.abs(),
        half_h: box_size.y.abs() * 0.5 * scale.y.abs(),
        local_dir_x: local_dir.x,
        local_dir_y: local_dir.y,
        dir_x: world_dir.x,
        dir_y: world_dir.y,
        power_factor: overrides.power_factor.unwrap_or(defaults.power_factor),
        systems,
    }
}

fn wind_particle_side_velocity(area: &WindAreaDef, system_index: usize, t: f32) -> f32 {
    wind_area_particle_system(area, system_index)
        .velocity_y
        .sample(t, 0.0)
}

fn wind_particle_size_scale(area: &WindAreaDef, system_index: usize, t: f32) -> f32 {
    wind_area_particle_system(area, system_index)
        .size_over_lifetime
        .sample(t, 0.0)
}

fn update_wind_particle(particle: &mut WindParticle, area: &WindAreaDef, dt: f32) -> bool {
    particle.age += dt;
    if particle.age >= particle.lifetime {
        return false;
    }

    let t_frac = particle.age / particle.lifetime;
    let side_velocity = wind_particle_side_velocity(area, particle.source_system_index, t_frac);
    particle.x += (particle.vx + particle.side_x * side_velocity) * dt;
    particle.y += (particle.vy + particle.side_y * side_velocity) * dt;
    particle.rot += particle.rot_speed * dt;
    true
}

#[cfg_attr(not(test), allow(dead_code))]
fn prewarm_wind_particle(particle: &mut WindParticle, area: &WindAreaDef, target_age: f32) {
    let target_age = target_age.clamp(0.0, (particle.lifetime - f32::EPSILON).max(0.0));
    while particle.age < target_age {
        let step = (target_age - particle.age).min(1.0 / 60.0);
        if !update_wind_particle(particle, area, step) {
            break;
        }
    }
}

fn prewarm_wind_system(
    area: &WindAreaDef,
    area_index: usize,
    system_index: usize,
    particles: &mut Vec<WindParticle>,
) -> f32 {
    let system = wind_area_particle_system(area, system_index);
    if !system.prewarm {
        return 0.0;
    }

    let duration = system.duration.max(f32::EPSILON);
    let mut local_particles = Vec::new();
    let mut spawn_accum = 0.0;
    let mut spawn_serial = 0u32;
    let mut remaining = duration;

    while remaining > 0.0 {
        let dt = remaining.min(1.0 / 60.0);
        spawn_accum += dt * wind_area_particle_spawn_rate(area, system_index);
        while spawn_accum + WIND_EMISSION_SPAWN_EPSILON >= 1.0
            && local_particles.len() < wind_area_particle_max_count(area, system_index)
        {
            spawn_accum = (spawn_accum - 1.0).max(0.0);
            let seed = area_index as u32 * 1009 + system_index as u32 * 313 + spawn_serial * 17;
            spawn_wind_particle(area, system_index, &mut local_particles, seed);
            spawn_serial = spawn_serial.wrapping_add(1);
        }

        let mut particle_index = 0;
        while particle_index < local_particles.len() {
            if !update_wind_particle(&mut local_particles[particle_index], area, dt) {
                local_particles.swap_remove(particle_index);
                continue;
            }
            particle_index += 1;
        }

        remaining -= dt;
    }

    particles.extend(local_particles);
    spawn_accum
}

/// Spawn a wind leaf particle in the given area/system.
fn spawn_wind_particle(
    area: &WindAreaDef,
    system_index: usize,
    particles: &mut Vec<WindParticle>,
    seed: u32,
) {
    let dir_len = (area.dir_x * area.dir_x + area.dir_y * area.dir_y)
        .sqrt()
        .max(f32::EPSILON);
    let dir_x = area.dir_x / dir_len;
    let dir_y = area.dir_y / dir_len;
    let side_x = -dir_y;
    let side_y = dir_x;
    let (emitter_offset_dir, emitter_offset_side) =
        wind_particle_emitter_offsets(area, system_index);
    let emitter_center_x =
        area.center_x + dir_x * emitter_offset_dir + side_x * emitter_offset_side;
    let emitter_center_y =
        area.center_y + dir_y * emitter_offset_dir + side_y * emitter_offset_side;
    let shape_offset =
        wind_particle_shape_spawn_offset(area, system_index, seed.wrapping_mul(7).wrapping_add(1));
    let x = emitter_center_x + shape_offset.x;
    let y = emitter_center_y + shape_offset.y;
    let size_random = pseudo_random(seed.wrapping_mul(11).wrapping_add(5));
    let speed_random = pseudo_random(seed.wrapping_mul(13).wrapping_add(9));
    let rot_random = pseudo_random(seed.wrapping_mul(23));
    let frame_random = pseudo_random(seed.wrapping_mul(31).wrapping_add(13));
    let rot_sign = if seed.is_multiple_of(2) { 1.0 } else { -1.0 };
    let size = wind_particle_start_size(area, system_index, size_random);
    let speed = wind_particle_start_speed(area, system_index, speed_random);
    particles.push(WindParticle {
        x,
        y,
        vx: dir_x * speed,
        vy: dir_y * speed,
        side_x,
        side_y,
        age: 0.0,
        lifetime: wind_particle_lifetime(area, system_index, speed_random),
        rot: wind_particle_start_rotation(area, system_index, rot_random),
        rot_speed: wind_particle_rotation_speed(area, system_index, rot_random) * rot_sign,
        size,
        leaf_col: wind_particle_uv_column(area, system_index, frame_random),
        source_sprite_index: area.sprite_index,
        source_system_index: system_index,
    });
}

impl LevelRenderer {
    pub(crate) fn seed_wind_particles(&mut self) {
        self.wind_particles.clear();
        let system_count = wind_area_particle_system_count();
        self.wind_spawn_accum = vec![0.0; self.wind_areas.len() * system_count];
        for (area_index, area) in self.wind_areas.iter().enumerate() {
            for system_index in 0..system_count {
                let accum_index = area_index * system_count + system_index;
                self.wind_spawn_accum[accum_index] =
                    prewarm_wind_system(area, area_index, system_index, &mut self.wind_particles);
            }
        }
    }

    pub(super) fn update_wind_particles(&mut self, dt: f32) {
        // Spawn new particles
        let system_count = wind_area_particle_system_count();
        for a in 0..self.wind_areas.len() {
            for system_index in 0..system_count {
                let accum_index = a * system_count + system_index;
                self.wind_spawn_accum[accum_index] +=
                    dt * wind_area_particle_spawn_rate(&self.wind_areas[a], system_index);
                let mut area_count = self
                    .wind_particles
                    .iter()
                    .filter(|p| {
                        p.source_sprite_index == self.wind_areas[a].sprite_index
                            && p.source_system_index == system_index
                    })
                    .count();
                while self.wind_spawn_accum[accum_index] + WIND_EMISSION_SPAWN_EPSILON >= 1.0
                    && area_count < wind_area_particle_max_count(&self.wind_areas[a], system_index)
                {
                    self.wind_spawn_accum[accum_index] =
                        (self.wind_spawn_accum[accum_index] - 1.0).max(0.0);
                    let seed = (self.time * 1000.0) as u32
                        + a as u32 * 977
                        + system_index as u32 * 313
                        + self.wind_particles.len() as u32 * 131;
                    spawn_wind_particle(
                        &self.wind_areas[a],
                        system_index,
                        &mut self.wind_particles,
                        seed,
                    );
                    area_count += 1;
                }
            }
        }
        // Update particles
        let area_lookup: HashMap<usize, &WindAreaDef> = self
            .wind_areas
            .iter()
            .map(|area| (area.sprite_index, area))
            .collect();
        let mut i = 0;
        while i < self.wind_particles.len() {
            let p = &mut self.wind_particles[i];
            let Some(area) = area_lookup.get(&p.source_sprite_index).copied() else {
                self.wind_particles.swap_remove(i);
                continue;
            };
            if !update_wind_particle(p, area, dt) {
                self.wind_particles.swap_remove(i);
                continue;
            }
            i += 1;
        }
    }
}

/// Draw wind leaf particles (from Particles_Sheet_01.png 16×16 grid).
pub(crate) fn draw_wind_particles(
    particles: &[WindParticle],
    wind_areas: &[WindAreaDef],
    source_sprite_index: Option<usize>,
    draw_ctx: &DrawCtx<'_>,
    tex_id: Option<crate::gpu2d::TextureId>,
) {
    let Some(leaf_tex) = tex_id else { return };
    let selected_area = source_sprite_index.and_then(|sprite_index| {
        wind_areas
            .iter()
            .find(|area| area.sprite_index == sprite_index)
    });
    for p in particles {
        let area = if let Some(area) = selected_area {
            if p.source_sprite_index != area.sprite_index {
                continue;
            }
            area
        } else {
            let Some(area) = wind_areas
                .iter()
                .find(|area| area.sprite_index == p.source_sprite_index)
            else {
                continue;
            };
            area
        };
        let t_frac = p.age / p.lifetime;
        let size_scale = wind_particle_size_scale(area, p.source_system_index, t_frac);
        let alpha = size_scale.clamp(0.0, 1.0);
        let sz = p.size * size_scale * draw_ctx.camera.zoom;
        if sz < 0.5 {
            continue;
        }
        let center = draw_ctx
            .camera
            .world_to_screen(Vec2 { x: p.x, y: p.y }, draw_ctx.canvas_center);
        if !draw_ctx.canvas_rect.expand(20.0).contains(center) {
            continue;
        }

        let (tiles_x, tiles_y, row_index) = wind_particle_uv_layout(area, p.source_system_index);
        let (u0, u1, v0, v1) = particle_sheet_uv_rect(tiles_x, tiles_y, row_index, p.leaf_col);

        let hw = sz * 0.5;
        let hh = sz * 0.5;
        let cos_r = p.rot.cos();
        let sin_r = p.rot.sin();
        let rot_pt = |dx: f32, dy: f32| -> crate::gpu2d::Pos2 {
            crate::gpu2d::pos2(
                center.x + dx * cos_r + dy * sin_r,
                center.y - dx * sin_r + dy * cos_r,
            )
        };

        let a = (alpha * 255.0) as u8;
        let color = crate::gpu2d::Color32::from_rgba_unmultiplied(255, 255, 255, a);

        let mut mesh = crate::gpu2d::Mesh::with_texture(leaf_tex);
        mesh.vertices.push(crate::gpu2d::epaint::Vertex {
            pos: rot_pt(-hw, -hh),
            uv: crate::gpu2d::pos2(u0, v0),
            color,
        });
        mesh.vertices.push(crate::gpu2d::epaint::Vertex {
            pos: rot_pt(hw, -hh),
            uv: crate::gpu2d::pos2(u1, v0),
            color,
        });
        mesh.vertices.push(crate::gpu2d::epaint::Vertex {
            pos: rot_pt(hw, hh),
            uv: crate::gpu2d::pos2(u1, v1),
            color,
        });
        mesh.vertices.push(crate::gpu2d::epaint::Vertex {
            pos: rot_pt(-hw, hh),
            uv: crate::gpu2d::pos2(u0, v1),
            color,
        });
        mesh.indices.extend_from_slice(&[0, 1, 2, 0, 2, 3]);
        draw_ctx.painter.add(crate::gpu2d::Shape::mesh(mesh));
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    const LEVEL_01_WINDAREA_OVERRIDE: &str = "GameObject WindArea\n\tComponent UnityEngine.BoxCollider\n\t\tVector3 m_Size\n\t\t\tFloat x = 31.4\n\tComponent WindArea\n\t\tVector3 windDirectionHandle\n\t\t\tFloat x = 17.67106\n\t\t\tFloat y = 0.617309\n\t\t\tFloat z = 0\n\t\tFloat m_windPowerFactor = 0.26\n\tGameObject WindEffect1\n\t\tComponent UnityEngine.Transform\n\t\t\tQuaternion m_LocalRotation\n\t\t\t\tFloat x = 0.0005903003\n\t\t\t\tFloat y = 0.7071065\n\t\t\t\tFloat z = -0.0005903003\n\t\t\t\tFloat w = 0.7071065\n\t\t\tVector3 m_LocalPosition\n\t\t\t\tFloat x = -15.69998\n\t\t\t\tFloat y = 0.01111133\n\t\t\t\tFloat z = -2\n\t\tComponent UnityEngine.ParticleSystem\n\t\t\tGeneric InitialModule\n\t\t\t\tGeneric startLifetime\n\t\t\t\t\tFloat scalar = 5.233333\n\t\t\t\tGeneric startSpeed\n\t\t\t\t\tFloat scalar = 6\n\t\t\tGeneric EmissionModule\n\t\t\t\tGeneric rate\n\t\t\t\t\tFloat scalar = 1\n";

    fn test_wind_area(dir_x: f32, dir_y: f32) -> WindAreaDef {
        let local_dir = normalize_vec2(Vec2 { x: dir_x, y: dir_y });
        WindAreaDef {
            sprite_index: 0,
            center_x: 0.0,
            center_y: 0.0,
            render_z: 0.0,
            half_w: 20.0,
            half_h: 7.5,
            local_dir_x: local_dir.x,
            local_dir_y: local_dir.y,
            dir_x,
            dir_y,
            power_factor: 1.5,
            systems: default_wind_area_systems(),
        }
    }

    #[test]
    fn wind_area_particles_follow_area_direction() {
        let mut particles = Vec::new();
        spawn_wind_particle(&test_wind_area(0.0, 8.0), 0, &mut particles, 0);

        let particle = &particles[0];
        assert!(particle.vy > 0.0);
        assert!(particle.vy.abs() > particle.vx.abs());
    }

    #[test]
    fn wind_area_prefab_defaults_match_embedded_prefab() {
        let area = build_wind_area_def(
            0,
            Vec2 { x: 0.0, y: 0.0 },
            0.0,
            0.0,
            Vec2 { x: 1.0, y: 1.0 },
            None,
        );

        assert!((area.half_w - 20.0).abs() < 0.0001);
        assert!((area.half_h - 7.5).abs() < 0.0001);
        assert!((area.power_factor - 1.5).abs() < 0.0001);
        assert!((area.local_dir_x - 0.61064816).abs() < 0.0001);
        assert!((area.local_dir_y - (-0.79190195)).abs() < 0.0001);
    }

    #[test]
    fn wind_particle_side_velocity_curve_matches_unity_prefab_sign_changes() {
        let area = build_wind_area_def(
            0,
            Vec2 { x: 0.0, y: 0.0 },
            0.0,
            0.0,
            Vec2 { x: 1.0, y: 1.0 },
            None,
        );

        assert!(wind_particle_side_velocity(&area, 0, 0.0) < 0.0);
        assert!(wind_particle_side_velocity(&area, 0, 0.06) > 0.0);
        assert!(wind_particle_side_velocity(&area, 0, 0.30) < 0.0);
        assert!(wind_particle_side_velocity(&area, 0, 0.75) > 0.0);
    }

    #[test]
    fn wind_particle_emitter_offsets_match_prefab_xy_plane() {
        let area = build_wind_area_def(
            0,
            Vec2 { x: 0.0, y: 0.0 },
            0.0,
            0.0,
            Vec2 { x: 1.0, y: 1.0 },
            None,
        );
        let (dir_offset, side_offset) = wind_particle_emitter_offsets(&area, 0);
        assert!((dir_offset + 12.161071).abs() < 0.001);
        assert!((side_offset + 6.0450926).abs() < 0.001);
    }

    #[test]
    fn wind_particle_size_curve_matches_unity_prefab_envelope() {
        let area = build_wind_area_def(
            0,
            Vec2 { x: 0.0, y: 0.0 },
            0.0,
            0.0,
            Vec2 { x: 1.0, y: 1.0 },
            None,
        );

        assert_eq!(wind_particle_size_scale(&area, 0, 0.0), 0.0);
        assert!(wind_particle_size_scale(&area, 0, 0.03) > 0.5);
        assert!((wind_particle_size_scale(&area, 0, 0.5) - 1.0889437).abs() < 0.001);
        assert!(wind_particle_size_scale(&area, 0, 0.95) < 0.5);
    }

    #[test]
    fn wind_particle_runtime_uses_source_system_specific_curves() {
        let area = build_wind_area_def(
            0,
            Vec2 { x: 0.0, y: 0.0 },
            0.0,
            0.0,
            Vec2 { x: 1.0, y: 1.0 },
            None,
        );

        assert_eq!(area.systems[0].uv_module.sample_frame_index(0.0), 4);
        assert_eq!(area.systems[2].uv_module.sample_frame_index(0.0), 5);
        assert_ne!(
            wind_particle_size_scale(&area, 0, 0.01).to_bits(),
            wind_particle_size_scale(&area, 2, 0.01).to_bits()
        );
    }

    #[test]
    fn wind_particle_update_uses_perpendicular_sway_axis() {
        let area = build_wind_area_def(
            0,
            Vec2 { x: 0.0, y: 0.0 },
            0.0,
            0.0,
            Vec2 { x: 1.0, y: 1.0 },
            None,
        );
        let lifetime = wind_particle_lifetime(&area, 0, 0.0);
        let mut particle = WindParticle {
            x: 0.0,
            y: 0.0,
            vx: 0.0,
            vy: 8.0,
            side_x: 1.0,
            side_y: 0.0,
            age: lifetime * 0.04,
            lifetime,
            rot: 0.0,
            rot_speed: 0.0,
            size: 0.5,
            leaf_col: 0,
            source_sprite_index: 0,
            source_system_index: 0,
        };

        assert!(update_wind_particle(&mut particle, &area, lifetime * 0.02));
        assert!(particle.x.abs() > 0.01);
        assert!(particle.y > 0.5);
    }

    #[test]
    fn wind_area_level01_override_produces_horizontal_runtime_values() {
        let area = build_wind_area_def(
            0,
            Vec2 {
                x: 16.059305,
                y: 0.62,
            },
            0.0,
            0.0,
            Vec2 { x: 2.0, y: 1.0 },
            Some(LEVEL_01_WINDAREA_OVERRIDE),
        );

        assert!((area.dir_x - 1.0).abs() < 0.01);
        assert!(area.dir_y.abs() < 0.01);
        assert!((area.half_w - 31.4).abs() < 0.01);
        assert!((area.power_factor - 0.26).abs() < 0.0001);
        assert!((area.systems[0].local_position.x + 31.39996).abs() < 0.01);
        assert!((area.systems[0].local_position.y - 0.01111133).abs() < 0.0001);
        assert_eq!(area.systems[0].local_position.z, -2.0);
        assert_eq!(area.render_z, -2.0);
        let extents = area.systems[0].projected_ellipsoid_half_extents_xy();
        assert!(extents.x > 1.9);
        assert!((area.systems[0].start_lifetime.sample(0.0, 0.0) - 5.233333).abs() < 0.0001);
        assert!((area.systems[0].start_speed.sample(0.0, 0.0) - 6.0).abs() < 0.0001);

        let mut particles = Vec::new();
        spawn_wind_particle(&area, 0, &mut particles, 0);
        let particle = &particles[0];
        assert!(particle.vx > 5.9);
        assert!(particle.vx.abs() > particle.vy.abs() * 100.0);
    }

    #[test]
    fn wind_particle_horizontal_area_spawns_across_prefab_shape() {
        let area = build_wind_area_def(
            0,
            Vec2 {
                x: 16.059305,
                y: 0.62,
            },
            0.0,
            0.0,
            Vec2 { x: 2.0, y: 1.0 },
            Some(LEVEL_01_WINDAREA_OVERRIDE),
        );

        let mut particles = Vec::new();
        for seed in 0..16 {
            spawn_wind_particle(&area, 0, &mut particles, seed);
        }

        let min_x = particles.iter().map(|p| p.x).fold(f32::INFINITY, f32::min);
        let max_x = particles
            .iter()
            .map(|p| p.x)
            .fold(f32::NEG_INFINITY, f32::max);
        let min_y = particles.iter().map(|p| p.y).fold(f32::INFINITY, f32::min);
        let max_y = particles
            .iter()
            .map(|p| p.y)
            .fold(f32::NEG_INFINITY, f32::max);

        let x_span = max_x - min_x;
        let y_span = max_y - min_y;
        assert!(x_span > 1.0);
        assert!(y_span > 1.0);
        assert!(x_span > 0.0);
    }

    #[test]
    fn wind_prewarm_advances_particle_state() {
        let area = test_wind_area(0.0, 8.0);
        let mut particles = Vec::new();
        spawn_wind_particle(&area, 0, &mut particles, 123);

        let mut particle = particles.pop().expect("wind particle should spawn");
        let initial_x = particle.x;
        let initial_y = particle.y;
        let initial_rot = particle.rot;
        let target_age = particle.lifetime * 0.5;

        prewarm_wind_particle(&mut particle, &area, target_age);

        assert!(particle.age > 0.0);
        assert!(
            (particle.x - initial_x).abs() > 0.0001
                || (particle.y - initial_y).abs() > 0.0001
                || (particle.rot - initial_rot).abs() > 0.0001
        );
    }

    #[test]
    fn wind_prewarm_tracks_emission_phase_from_prefab_duration() {
        let area = test_wind_area(0.0, 8.0);
        let mut particles = Vec::new();

        let spawn_accum = prewarm_wind_system(&area, 0, 0, &mut particles);

        assert_eq!(particles.len(), 5);
        assert!(spawn_accum.abs() < 0.01);
        assert!(particles.iter().all(|particle| particle.age > 0.0));
    }
}
